<?php
declare(strict_types=1);

/*
 * Seguridad recomendada:
 * - Mover este archivo fuera de public_html.
 * - Si lo mueves, cambia el require_once en api/proxy.php.
 */

const APPS_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbwuhwHAdoY52m7Ex7y9dU__Ptj-0t1Z8ZHnZdECXSAIxC_-9R6TGslBdAAVeowgPdakuQ/exec";
const APPS_SCRIPT_TOKEN = "Mylder_Agenda_2026!x9Q#k2Lm8P@r7V";

/*
 * Rate limit global por acción e IP.
 * window_seconds: ventana de tiempo
 * max_requests: solicitudes máximas por ventana
 */
const PROXY_RATE_LIMIT = [
  "window_seconds" => 300,
  "max_requests" => 30
];

